Drag and Drop "flexlion3" folder to the root of Switch SD Card
(Merge Contents if prompted)

Not all color configs are 100% accurate so you can adjust them yourself, will continue to update overtime if possible.

Credit: @nvnprogram for creating "Flexlion Mod Menu". @PotionMaster21, @kyrowhaffle for configs.
discord.gg/theecorner for hosting the included themes.


CUSTOM THEMES:

Rock vs. Chiptune vs. Hyperpop
Physical Touch vs. Gift Giving vs. Quality Time
Lilies vs. Lotuses vs. Blossoms
Burgers vs. Tacos vs. Pizza
Miku vs. Luka vs. Rin
Ninjas vs. Cowboys vs. Pirates
Penguins vs. Seals vs. Otters
Cookies vs. Ice Cream vs. Cakes
Werewolves vs. Vampires vs. Witches
Soar Throat vs. Headache vs. Runny Nose