Drag and Drop "flexlion3" folder to the root of Switch SD Card
(Merge Contents if prompted)

Not all color configs are 100% accurate so you can adjust them yourself, will continue to update overtime if possible.

Credit: @nvnprogram for creating "Flexlion Mod Menu". @PotionMaster21, @kyrowhaffle for configs.
discord.gg/coralreef for hosting the included themes.


CUSTOM THEMES:

Art vs. Maths vs. Science
Watermelons vs. Mangoes vs. Pineapples
Rosalina vs. Daisy vs. Peach
Growth vs. Stability vs. Change
Candy vs. Costumes vs. Vibes
Morning vs. Afternoon vs. Night
Hot Cocoa vs. Pudding vs. Cookies